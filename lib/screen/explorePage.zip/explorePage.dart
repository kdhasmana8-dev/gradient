import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:gradient/screen/deatils2_page.dart';
import 'package:gradient/screen/details_page.dart';
import 'package:gradient/screen/payment_page.dart';



class PropertyHomePage extends StatefulWidget {
  const PropertyHomePage({super.key});

  @override
  State<PropertyHomePage> createState() => _PropertyHomePageState();
}

class _PropertyHomePageState extends State<PropertyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F1624),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: [
              // -----------------------------
              // TOP MENU + SEARCH
              // -----------------------------
              Row(
                children: [
                  GestureDetector(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>SideMenu3D()));
              },
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF1C2334),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.all(10),
                    child: const Icon(Icons.menu, color: Colors.white),
                  ),
                  ),
                  const SizedBox(width: 12),

                  // Search Bar
                  Expanded(
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1C2334),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          const Icon(Icons.search, color: Colors.grey),
                          const SizedBox(width: 10),
                          const Text("Where to?",
                              style:
                              TextStyle(color: Colors.grey, fontSize: 16)),
                          const Spacer(),
                          const Icon(Icons.mic, color: Colors.grey),
                        ],
                      ),
                    ),
                  )
                ],
              ),

              const SizedBox(height: 20),

              // -----------------------------
              // PROPERTY CARD LIST
              // -----------------------------
              Expanded(
                child: ListView(
                  children: [
                    buildPropertyCard(
                      img: "assets/images/wallpaper.jpg",
                      location: "Toronto, Canada",
                      price: "\$200 CAD / night",
                      distance: "257 km",
                      date: "Oct 24 - 26",
                      rating: "4.1 (1,648)",
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const LuxuryStayPage()),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    buildPropertyCard(
                      img: "assets/images/wallpaper3.jpg",
                      location: "Toronto, Canada",
                      price: "\$200 CAD / night",
                      distance: "257 km",
                      date: "Oct 24 - 26",
                      rating: "4.1 (1,648)",
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>LuxuryStayPage1()));
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // -----------------------------
      // BOTTOM NAVIGATION BAR
      // -----------------------------
      bottomNavigationBar: Container(
        height: 75,
        decoration: const BoxDecoration(
          color: Color(0xFF1C2334),
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: const [
            Icon(Icons.radar, color: Colors.blueAccent, size: 32),
            Icon(Icons.flight, color: Colors.white, size: 28),
            Icon(Icons.favorite_border, color: Colors.white, size: 28),
            Icon(Icons.message, color: Colors.white, size: 28),
          ],
        ),
      ),
    );
  }
}

//
// ⭐ RATING BADGE UI (same as screenshot)
//
Widget ratingBadge(String rating) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.55),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.star, color: Colors.lightBlueAccent, size: 18),
        const SizedBox(width: 6),
        Text(
          rating,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );
}

//
// PROPERTY CARD WIDGET
//
Widget buildPropertyCard({
  required String img,
  required String location,
  required String price,
  required String distance,
  required String date,
  required String rating,
  required Function() onTap,
}) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1C2334),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // -----------------------------
          // IMAGE + BADGE + FAVORITE ICON
          // -----------------------------
          Stack(
            children: [
              ClipRRect(
                borderRadius:
                const BorderRadius.vertical(top: Radius.circular(24)),
                child: Image.asset(
                  img,
                  height: 220,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),

              // ⭐ Rating Badge (top center)
              Positioned(
                top: 12,
                left: 0,
                right: 0,
                child: Center(child: ratingBadge(rating)),
              ),

              // ❤️ Favorite Icon
              const Positioned(
                right: 16,
                top: 16,
                child: Icon(Icons.favorite_border,
                    color: Colors.white, size: 28),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // LOCATION
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              location,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(height: 14),

          // -----------------------------
          // COST | DISTANCE | DATE BOX
          // -----------------------------
          Container(
            padding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
              color: Color(0xFF1C2334),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Cost
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("COST",
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
                    Text(price,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 15)),
                  ],
                ),

                // Distance
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("DISTANCE",
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
                    Row(
                      children: [
                        const Icon(Icons.navigation,
                            color: Colors.cyanAccent, size: 16),
                        const SizedBox(width: 4),
                        Text(distance,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 15)),
                      ],
                    ),
                  ],
                ),

                // Available
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("AVAILABLE",
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
                    Row(
                      children: [
                        const Icon(Icons.calendar_today,
                            color: Colors.cyanAccent, size: 16),
                        const SizedBox(width: 4),
                        Text(date,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 15)),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}



class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  bool isMenuOpen = false;
  int selectedIndex = 1;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  void toggleMenu() {
    isMenuOpen ? _controller.reverse() : _controller.forward();
    isMenuOpen = !isMenuOpen;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0F1F),
      body: Stack(
        children: [
          // ----------------------
          // EXPLORE PAGE CONTENT
          // ----------------------
          AnimatedBuilder(
            animation: _controller,
            builder: (_, child) {
              double slide = 280 * _controller.value;
              double scale = 1 - (0.18 * _controller.value);
              double rotate = -0.12 * _controller.value;

              return Transform(
                alignment: Alignment.centerLeft,
                transform: Matrix4.identity()
                  ..translate(slide)
                  ..scale(scale)
                  ..rotateY(rotate),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(
                      _controller.value * 28), // curve when open
                  child: child,
                ),
              );
            },
            child: buildExplorePageUI(),
          ),

          // ----------------------
          // 3D MENU PANEL
          // ----------------------
          build3DSidePanel(),

          // ----------------------
          // MENU ICON BUTTON
          // ----------------------
          Positioned(
            top: 50,
            left: 20,
            child: IconButton(
              icon: const Icon(Icons.menu, color: Colors.white, size: 32),
              onPressed: toggleMenu,
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------
  // YOUR ORIGINAL EXPLORE PAGE CONTENT GOES HERE
  // ------------------------------------------
  Widget buildExplorePageUI() {
    return GestureDetector(
      onTap: isMenuOpen ? toggleMenu : null,
      child: Container(
        color: Colors.white,
        child: const Center(
          child: Text(
            "Explore Page Content",
            style: TextStyle(fontSize: 22),
          ),
        ),
      ),
    );
  }

  // ----------------------
  // SIDE MENU PANEL (same as your code)
  // ----------------------
  Widget build3DSidePanel() {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return Transform.translate(
          offset: Offset(-260 + (260 * _controller.value), 0),
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(38),
              bottomRight: Radius.circular(38),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
              child: Container(
                width: 260,
                padding:
                const EdgeInsets.symmetric(horizontal: 22, vertical: 30),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.10),
                      Colors.white.withOpacity(0.03),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border(
                    right: BorderSide(
                        color: Colors.white.withOpacity(0.08), width: 1),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.55),
                      blurRadius: 40,
                      offset: const Offset(10, 0),
                    ),
                  ],
                ),
                child: buildMenuList(),
              ),
            ),
          ),
        );
      },
    );
  }

  // ----------------------
  // MENU LIST (same as your code)
  // ----------------------
  Widget buildMenuList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const CircleAvatar(
              radius: 28,
              backgroundImage: AssetImage("assets/profile.jpg"),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Alice Portman",
                    style: TextStyle(color: Colors.white, fontSize: 16)),
                Text("Show Profile",
                    style: TextStyle(color: Colors.white54, fontSize: 13)),
              ],
            ),
          ],
        ),

        const SizedBox(height: 30),
        sectionTitle("Account Setting"),

        menuTile(0, Icons.notifications, "Notifications", badge: "12"),
        menuTile(1, Icons.credit_card, "Payment"),
        menuTile(2, Icons.translate, "Translate"),
        menuTile(3, Icons.lock_outline, "Privacy"),

        const SizedBox(height: 25),
        sectionTitle("Hosting"),

        menuTile(4, Icons.home_filled, "Listing"),
        menuTile(5, Icons.person_outline, "Host"),

        const SizedBox(height: 25),
        sectionTitle("More"),

        menuTile(6, Icons.dark_mode, "Dark Mode", trailingSwitch: true),
        menuTile(7, Icons.update, "Update"),
      ],
    );
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
            color: Colors.white54, fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }

  Widget menuTile(
      int index,
      IconData icon,
      String title, {
        String? badge,
        bool trailingSwitch = false,
      }) {
    bool isSelected = index == selectedIndex;

    return GestureDetector(
      onTap: () => setState(() => selectedIndex = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: isSelected
              ? LinearGradient(
            colors: [
              Colors.blueAccent.withOpacity(0.45),
              Colors.blueAccent.withOpacity(0.18),
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          )
              : null,
          color: isSelected
              ? Colors.blueAccent.withOpacity(0.32)
              : Colors.transparent,
        ),
        child: Row(
          children: [
            Icon(icon,
                color: isSelected ? Colors.white : Colors.white70, size: 22),
            const SizedBox(width: 14),

            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white70,
                  fontSize: 15,
                ),
              ),
            ),

            if (badge != null)
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  badge,
                  style:
                  const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),

            if (trailingSwitch)
              Switch(
                value: true,
                onChanged: (_) {},
                activeColor: Colors.blueAccent,
              ),
          ],
        ),
      ),
    );
  }
}
